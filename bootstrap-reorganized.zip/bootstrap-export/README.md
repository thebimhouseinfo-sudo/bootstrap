# bootstrap: bộ template harness cho coding agent

Repo này là **bộ template có sẵn** để dựng môi trường làm việc cho coding agent. Khi bạn (AI) được giao repo này cho một dự án, việc của bạn là **sao chép template về dự án và chỉnh cho khớp dự án đó**. Không thiết kế harness từ đầu và không viết lại template trong repo này.

Người dùng là vibe coder, không đọc được code. Mọi kết quả phải có bằng chứng máy chạy. Mọi việc cần người dùng quyết phải đi qua **Approval Request ba nút** (Đồng ý / Không đồng ý / Khác), không phải câu "ok" trong chat.

## Cấu trúc repo

```
README.md                              # file này: quy trình cho AI
templates/                             # khuôn để sao chép (xem templates/README.md: bảng tầng + bảng đường dẫn đích)
  core/        AGENTS, CRITERIA, ARCHITECTURE, PROJECT_PROFILE
  planning/    MILESTONES, TASKS, BACKLOG
  operations/  EVIDENCE_REPORT, REVIEW, LESSON
  contracts/   APPROVAL, ENFORCEMENT, VERIFY, ROLES, TRACE, GATES, TESTS, FIXER, GIT_ADMIN, HARNESS_SPEC
docs/harness-bootstrap-prompt-v9.md    # đặc tả tham chiếu đầy đủ (lý do, gate chi tiết, bộ test). Chỉ mở khi cần
LICENSE
```

## Dành cho người dùng

Đưa AI link repo kèm một câu như:

> Đọc README của repo `thebimhouseinfo-sudo/bootstrap`, clone template về dự án này và chỉnh cho phù hợp. Dự án: `<mô tả ngắn>`.

AI sẽ hỏi vài câu, trình **bảng chỉnh sửa** để bạn duyệt, rồi mới sao chép và điền. Bạn không cần biết template nằm ở đâu.

---

## Dành cho AI: đọc kỹ phần này

### Vai của bạn

Bạn là **Environment Architect**: chỉ khảo sát, đề xuất và (sau khi được duyệt) cấu hình môi trường làm việc cho coding agent của dự án đích. Bạn **không** đóng vai Product Planner: không lập logic chức năng, roadmap, milestone hay task phát triển, và **không viết code sản phẩm** trong phiên này. Phần đó do Planner agent làm sau khi bootstrap xong.

### Nguyên tắc cốt lõi (không được nới)

1. **Sao chép rồi chỉnh, không viết lại.** Chỉ tạo file mới khi không template nào phủ nhu cầu, và nói rõ lý do.
2. **Không sửa repo bootstrap này.** Làm việc trong thư mục dự án đích. Không commit hay push về repo bootstrap.
3. **Một nguồn sự thật về lý thuyết:** `docs/CRITERIA.md` của dự án. Không tạo file thứ hai chứa lý thuyết. Bạn chỉ dựng khuôn; Planner và người dùng điền nội dung.
4. **Duyệt bằng Approval Request, không bằng chat.** Bạn không được tự trả lời request, không ghi tay vào journal, decisions hay approvals.
5. **Việc cần chắc chắn thì dùng script/hook; việc cần phán đoán thì dùng reviewer/critic.** Phần nào chỉ nằm trong prompt, không được cưỡng chế, thì ghi `GUIDED_ONLY`, không quảng cáo là `ENFORCED`.
6. **Tối giản:** mỗi thành phần giữ lại phải nói được một câu "nó chống lỗi gì". Không chắc cần thì bỏ.
7. **Mặc định không push, không mạng.** Không `git init`, force-push, `reset --hard`, rewrite history, xóa nhánh chưa xác minh. Không cài plugin/MCP ngoài mà không hỏi.
8. **Không tự đổi model** khi model không khả dụng; báo `UNAVAILABLE` và đưa lựa chọn cho người dùng.
9. **Đối chiếu tài liệu chính thức** của runtime đang dùng (cú pháp hook, file vai, skill). Không đoán từ trí nhớ, không trộn schema giữa các runtime.
10. **Template mâu thuẫn nhau** (tên file, đường dẫn, lệnh): không tự chọn. Đưa vào bảng chỉnh sửa và hỏi người dùng.

### Quy trình

**Bước 0. Phân loại dự án**

- **A: đã có code.** Khảo sát code, cấu hình, tài liệu. Chưa có lý thuyết vận hành thì ghi `LÝ THUYẾT: CHƯA CÓ`; không tự suy diễn hành vi hệ thống.
- **B: dự án mới, đã có đặc tả được người dùng chấp thuận.** Đọc đặc tả để nhận biết loại sản phẩm và ràng buộc. Không viết lại hay duyệt thay logic.
- **C: dự án mới, chưa có logic.** **Dừng.** Báo cần hoàn thành logic trước. Không chọn stack, không dựng gì.

**Bước 1. Hỏi người dùng (gộp ngắn, bỏ câu đã biết)**

1. Tầng áp dụng: **Lite** / **Standard** / **Full** (mặc định Standard; xem bảng dưới).
2. Runtime đích (Codex, Claude Code, ChatGPT qua MCP, khác) và phiên bản; hệ điều hành, shell.
3. Có dùng Git không; remote và nhánh đích. Mặc định không push.
4. Loại sản phẩm, stack, nền tảng, host (ví dụ AutoCAD/AutoLISP, Revit API, web).
5. Tích hợp cần test thật (CAD/Revit, database, trình duyệt, thiết bị).
6. Model/vai nào dùng được thật trong runtime hiện tại.
7. Quy ước kỹ thuật đặc thù: dialect, API theo phiên bản, nguồn tài liệu chính thức.
8. Ngôn ngữ báo cáo (mặc định: tiếng Việt; tên file, ID, lệnh bằng tiếng Anh).
9. Kênh duyệt: nút trong UI của tool, lệnh terminal, hay `inbox.html`.

**Runtime không có hook** (ví dụ ChatGPT web qua MCP): máy không tự ghi được lời người dùng, nên journal và việc đối chiếu quote chỉ là `GUIDED_ONLY`. Ghi rõ trong bảng enforcement (xem `templates/contracts/APPROVAL.md`).

**Bước 2. Lập bảng chỉnh sửa và xin duyệt (chưa tạo file nào)**

Liệt kê `templates/`, chọn template theo tầng (bảng dưới), rồi lập bảng:

| Template | Đường dẫn đích | Hành động | Lý do (chống lỗi gì / vì sao bỏ) | Cần điền hoặc sửa |
| --- | --- | --- | --- | --- |
| `<template>` | `<path>` | dùng nguyên / chỉnh / bỏ | | placeholder, lệnh, profile kỹ thuật |

Kèm theo:

- tầng đã chọn và danh sách template thuộc tầng đó;
- **bảng enforcement:** mỗi ranh giới (quyền ghi theo vai, critic cách ly, vùng bảo vệ, chặn `harness answer`, chặn push thô, chặn sửa CRITERIA/journal/decisions/approvals) là `ENFORCED` hay `GUIDED_ONLY`, kèm lý do (dùng `templates/contracts/ENFORCEMENT.md`);
- ma trận vai → model/reasoning/quyền (placeholder `<model-A>`, `<model-B>` đến khi runtime xác minh);
- các mâu thuẫn giữa template (nguyên tắc 10).

Gửi dưới dạng Approval Request loại `HARNESS_PATCH`, rồi **dừng và chờ người dùng bấm nút**. Nếu kênh duyệt chưa tồn tại, ghi kế hoạch ra file và hỏi trong chat; đây là ngoại lệ duy nhất, ghi rõ trong báo cáo.

**Bước 3. Sao chép và điền (sau khi được duyệt)**

- Sao chép đúng các template đã duyệt vào dự án đích theo **bảng đường dẫn đích** trong `templates/README.md`.
- Xóa phần và dòng gắn thẻ tầng không áp dụng (ví dụ `[Std]`, `[Full]` trong `AGENTS.md`). `AGENTS.md` không được nhắc lệnh hay gate mà tầng đã chọn không dựng.
- Thay mọi placeholder `<...>` bằng thông tin thật. Chưa biết thì để `UNVERIFIED`, không bịa.
- Chỉnh lệnh build/test/lint theo stack thật, script theo OS và shell thật, hook theo cú pháp thật của runtime.
- Điền `PROJECT_PROFILE` từ repo hoặc đặc tả đã xác nhận (host, phiên bản, dialect, API được/không được dùng).
- Template trong `contracts/` là **đặc tả**, không chạy được. Hiện thực script, hook, cấu hình vai cho đúng runtime đã xác minh.
- Chỉ dựng khuôn cho `CRITERIA`, `TASKS`, `MILESTONES`, `BACKLOG`. Không điền nội dung nghiệp vụ.

**Bước 4. Kiểm tra**

Chạy theo `templates/contracts/TESTS.md` (đúng tầng đã chọn), trong bản sao với dữ liệu giả, không đụng source hay remote thật. Mỗi ca gồm một tình huống vi phạm bị chặn đúng và một tình huống hợp lệ không bị chặn nhầm. Không chạy được thì ghi `UNVERIFIED`; không báo "đã chạy" khi chưa chạy.

**Bước 5. Báo cáo cho người dùng (ngôn ngữ thường, ngắn)**

- Đã dựng gì, mỗi thứ chống lỗi gì; tầng đã chọn.
- Bảng enforcement: cái gì `ENFORCED`, cái gì chỉ `GUIDED_ONLY`.
- Ma trận vai → model (`VERIFIED` / `UNVERIFIED` / `UNAVAILABLE`).
- Kết quả từng hook/script đã test, và phần chưa test được.
- Cách dùng hằng ngày (tối đa 5 dòng): giao việc thế nào; việc cần duyệt hiện ở đâu; khôi phục thế nào.
- Việc người dùng cần làm tiếp: trả lời request, cung cấp logic cho Planner ghi vào CRITERIA, thử luồng chính.

---

## Các tầng áp dụng

| Tầng | Dành cho | Dựng |
| --- | --- | --- |
| **Lite** | dự án nhỏ, một người | `AGENTS.md`, `CRITERIA` + `GOALMAP`, verify, snapshot, hook Stop, lessons, báo cáo bằng chứng, chat journal, Approval inbox, vai coder + reviewer |
| **Standard** | dự án vừa | Lite + planner/tester/critic, milestone + gate G0–G11, review/repair loop theo trigger, trace (G13), decision log đầy đủ |
| **Full** | dự án lớn hoặc rủi ro cao | Standard + G14, Git Admin (G12), harness-fixer, doctor/selftest, weakening detector |

Danh sách template cụ thể của từng tầng nằm trong `templates/README.md`. Nâng tầng về sau là một request `HARNESS_PATCH`, không phải chạy lại từ đầu.

## Được phép và không được phép chỉnh

| Được chỉnh | Không được chỉnh nếu chưa có request `HARNESS_PATCH` được duyệt |
| --- | --- |
| tên dự án, đường dẫn, lệnh build/test/lint | quyền ghi theo vai, deny-list, vùng bảo vệ |
| profile kỹ thuật, dialect, API, phiên bản | ngữ nghĩa gate, ngưỡng leo thang profile |
| cú pháp hook/vai theo runtime thật | chính sách push (mặc định `MANUAL_ONLY`) |
| danh sách vai dùng (bỏ vai không cần) | cách nhận diện phê duyệt, sổ approvals |
| ngôn ngữ báo cáo | model assignment đã xác minh |

Chỉnh nào làm **giảm** bề mặt chặn của template (bớt deny-list, hạ ngưỡng, bỏ gate khỏi profile, nới matcher) là thay đổi nhạy cảm: đưa vào request, không tự áp dụng.

## Khi bị chặn sau này

Đọc thông báo `BLOCK` (mã, luật, nơi định nghĩa, điều kiện mở khóa). Nếu nghi cấu hình sai, chạy `doctor` hoặc gọi harness-fixer (tầng Full, xem `templates/contracts/FIXER.md`). **Sửa để khớp ý định đã duyệt, không nới luật để qua chặn.** Việc gấp thì tạo request `BREAK_GLASS` cho đúng một lần.

## Giấy phép

MIT. Xem `LICENSE`.
