# <Project>

<1-2 sentences: what the project does and for whom.>

> Tier markers: keep lines tagged for the approved tier and delete the rest.
> `[Lite]` always kept. `[Std]` Standard and Full. `[Full]` Full only. Delete this note and the tags when done.
> Any command or path that the chosen tier did not actually build must not be mentioned here.

## Commands
- [Lite] Verify: <verified command or UNVERIFIED>
- [Lite] Build/test/run: <verified commands or UNVERIFIED>
- [Std] Gate status / check: <verified command or NOT_CONFIGURED>
- [Full] Git admin preflight: <verified command or NOT_APPLICABLE>

## Sources and precedence
- [Lite] Product theory: `docs/CRITERIA.md` only; GOALMAP is inside it.
- [Std] Derived: `docs/MILESTONES.md`, `docs/TASKS.md`, tests and generated `docs/TRACE.md`.
- [Lite] Runtime constraints: `docs/PROJECT_PROFILE.md`.
- [Lite] Ambiguous or silent theory: report `THEORY_GAP`; do not invent behavior.
- Precedence when files disagree: approved CRITERIA > GOALMAP > MILESTONES > TASKS > code/tests > unrecorded chat.

## Workflow
- [Lite] One scoped task at a time, linked to one approved goal. Read the goal and its acceptance conditions first; open theory IDs only when in doubt.
- [Lite] Snapshot before edits; run verify afterward and attach real evidence (`docs/reports/`).
- [Std] At the start of each session run gate status; do the mandatory next step it reports (self-review, tester, reviewer, critic per approved triggers). The user does not need to remind you.
- [Lite] Anything that needs the user's decision is an Approval Request (Agree / Disagree / Other). Never ask for approval in chat and never answer a request yourself. Chat "ok" is not an approval.
- [Lite] Do not edit product theory, journal, decisions, approvals, generated state, or protected harness settings by ordinary file edit.
- [Lite] No direct push or destructive Git action. No new dependency without an approved request.
- [Lite] A rule that exists only in these instructions is `GUIDED_ONLY`, not `ENFORCED`.
- [Std] Critic is context-isolated. Reviewer judges findings only against the current goal; out-of-scope ideas go to `docs/BACKLOG.md`. Max 2 review loops per pair, then stop and ask.
- [Lite] A fix that takes more than one attempt gets a lesson in `lessons/`.
- [Std] If a block looks like a harness misconfiguration, read the BLOCK message and run doctor; do not bypass or weaken the rule. [Full] Call harness-fixer.

## Done
- [Lite] Verify PASS; acceptance evidence exists for the goal's conditions; limitations stated honestly.
- [Std] Gate check PASS and trace shows no STALE or OPEN item in scope.
- [Full] Git integration gate PASS when Git is in use.
