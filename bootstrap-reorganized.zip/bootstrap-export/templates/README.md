# Generic harness starter templates

Copy only the templates needed for the approved bootstrap tier. These are **scaffolds, not a working harness**. The step-by-step process is in the repository root `README.md`; the long-form rationale, gate details and tests are in `docs/harness-bootstrap-prompt-v9.md`.

## Tier selection

| Tier | Copy |
|---|---|
| Lite | `core/*`, `operations/EVIDENCE_REPORT.md`, `operations/LESSON.md`, `operations/REVIEW.md`, `contracts/VERIFY.md`, `contracts/APPROVAL.md`, `contracts/ENFORCEMENT.md`, `contracts/ROLES.md` (Coder + Reviewer rows only), `contracts/TESTS.md` (Lite section) |
| Standard | Lite + `planning/*`, `contracts/TRACE.md`, `contracts/GATES.md`, full `contracts/ROLES.md`, `contracts/TESTS.md` (Standard section) |
| Full | Standard + `contracts/FIXER.md`, `contracts/GIT_ADMIN.md`, `contracts/HARNESS_SPEC.md`, `contracts/TESTS.md` (Full section) |

## Target path map

Use these paths in the target project. They are the single agreed layout.

| Template | Target path in the project |
|---|---|
| `core/AGENTS.md` | `AGENTS.md` |
| `core/CRITERIA.md` | `docs/CRITERIA.md` (only source of truth for product theory; GOALMAP is section 13) |
| `core/ARCHITECTURE.md` | `docs/ARCHITECTURE.md` |
| `core/PROJECT_PROFILE.md` | `docs/PROJECT_PROFILE.md` |
| `planning/MILESTONES.md` | `docs/MILESTONES.md` |
| `planning/TASKS.md` | `docs/TASKS.md` |
| `planning/BACKLOG.md` | `docs/BACKLOG.md` |
| `operations/EVIDENCE_REPORT.md` | `docs/reports/<task-id>.md` (one per task) |
| `operations/REVIEW.md` | `docs/reports/<task-id>-review.md` (one per review) |
| `operations/LESSON.md` | `lessons/_TEMPLATE.md` |
| `contracts/*.md` | `harness/contracts/*.md` (specifications the implementer reads); `HARNESS_SPEC.md` goes to `harness/HARNESS_SPEC.md` |

Generated or machine-written files (never hand edited): `docs/TRACE.md`, `harness/state.json`, `harness/chat-journal.jsonl`, `harness/decisions.jsonl`, `harness/approvals.jsonl`, `harness/requests/`.

## Use

1. Complete intake and inventory existing files, commands and constraints. If a new project has no approved logic, stop (case C).
2. Present a harness-only proposal (the adaptation table in the root `README.md`) and get the required approval before installing anything.
3. Copy only the appropriate templates, mapping paths as above. Delete irrelevant sections and tier-tagged lines; fill placeholders with verified evidence or `UNVERIFIED`.
4. Implement executable scripts, hooks, role configs and UI **for the verified target runtime**; the contract templates are not executable.
5. Simulate allowed and blocked scenarios on a disposable copy (`contracts/TESTS.md`). Record `ENFORCED`, `GUIDED_ONLY`, `UNVERIFIED` honestly. Template presence is not a passing test.

Never copy real secrets, project-specific assumptions, model IDs, platform commands, or example product behavior into the target project by default.
